from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .serializers import StudentSerializer,DepartmentSerializer
from rest_framework import status
from .models import Department,Student
import json
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import generics
from django.shortcuts import render
from .models import Student

@api_view(["GET"])
@api_view(["POST"])
@api_view(["PUT"])
@api_view(["DELETE"])
@csrf_exempt
@permission_classes([IsAuthenticated])  
def welcome(request):
    content = {"message": "Welcome to the student_profile!"}
    return JsonResponse(content)

def get_profile(request):
    user = request.user.id
    student = Student.objects.filter()
    serializer = StudentSerializer(student, many=True)
    return JsonResponse({'student': serializer.data}, safe=False, status=status.HTTP_200_OK)


def add_profile(request):
    payload = json.loads(request.body)
    user = request.user
    try:
        department = Department.objects.get(id=payload["department"])
        student = Student.objects.create(
            std_id=payload["std_id"],
            first_name=payload["first_name"],
            last_name=payload["last_name"]
        )
        serializer = StudentSerializer(student)
        return JsonResponse({'student': serializer.data}, safe=False, status=status.HTTP_201_CREATED)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something terrible went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

def update_profile(request, std_id):
    user = request.user.id
    payload = json.loads(request.body)
    try:
        std_item = student.objects.filter(id=std_id)
        # returns 1 or 0
        std_item.update(**payload)
        student = Student.objects.get(id=std_id)
        serializer = StudentSerializer(student)
        return JsonResponse({'student': serializer.data}, safe=False, status=status.HTTP_200_OK)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something terrible went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

def delete_profile(request, std_id):
    user = request.user.id
    try:
        student = Student.objects.get(id=std_id)
        student.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    except ObjectDoesNotExist as e:
        return JsonResponse({'error': str(e)}, safe=False, status=status.HTTP_404_NOT_FOUND)
    except Exception:
        return JsonResponse({'error': 'Something went wrong'}, safe=False, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

class DepartmentListView(generics.ListCreateAPIView):
    queryset = Department.objects.all()
    serializer_class = DepartmentSerializer


class DepartmentView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = DepartmentSerializer
    queryset = Department.objects.all()


class StudentListView(generics.ListCreateAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer


class StudentView(generics.RetrieveUpdateDestroyAPIView):
    serializer_class = StudentSerializer
    queryset = Student.objects.all()