from rest_framework import serializers,fields
from .models import Department,Student

class DepartmentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Department
        fields = ['dept_id', 'dept_name', 'dept_head']

class StudentSerializer(serializers.ModelSerializer):
    #department_student=DepartmentSerializer(read_only=True,many=True)
    class Meta:
        model = Student
        fields = ['std_id', 'first_name', 'last_name']
    
